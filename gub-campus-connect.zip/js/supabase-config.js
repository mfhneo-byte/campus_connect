/* ============================================================
   Supabase connection — fill in your project's credentials

   Where to find them: Supabase dashboard → your project →
   Project Settings (gear icon) → API.
     - projectUrl : "Project URL"        e.g. https://xxxxxxxx.supabase.co
     - anonKey    : "anon" / "publishable" key (long string starting "eyJ...")

   Never paste the "service_role" key here — that one bypasses all
   security and must never appear in client-side code. The anon key
   is the one designed to ship in the browser; Row Level Security
   (set up by supabase-schema.sql) is what keeps it safe.

   Leave both empty ("") and the app keeps working exactly as before,
   using localStorage — nothing breaks while you're setting this up.
   ============================================================ */

window.GUBCC_SUPABASE_CONFIG = {
  projectUrl: "",
  anonKey: ""
};
